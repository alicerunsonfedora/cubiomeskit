// swift-tools-version: 6.2
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "MyMapRenderer",
    platforms: [.macOS(.v13)],
    dependencies: [
        .package(url: "https://source.marquiskurt.net/AlidadeMC/cubiomeskit", branch: "80f2f5ba38")
    ],
    targets: [
        .executableTarget(
            name: "MyMapRenderer",
            dependencies: [
                .product(name: "CubiomesKit", package: "cubiomeskit")
            ]
        ),
    ]
)
