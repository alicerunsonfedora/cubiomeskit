//
//  ContentView.swift
//  HermitcraftMaps
//
//  Created by Marquis Kurt on 29-10-2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationSplitView {
            List {
                ForEach(HermitcraftWorld.pointsOfInterest) { poi in
                    Label(poi.name, systemImage: "mappin")
                }
            }
            .frame(minWidth: 200, idealWidth: 250)
        } detail: {
            HermitcraftMap()
        }
    }
}

#Preview {
    ContentView()
}
