//
//  HermitcraftMapsApp.swift
//  HermitcraftMaps
//
//  Created by Marquis Kurt on 29-10-2025.
//

import SwiftUI

@main
struct HermitcraftMapsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
