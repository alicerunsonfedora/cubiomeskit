//
//  Models.swift
//  HermitcraftMaps
//
//  Created by Marquis Kurt on 29-10-2025.
//

import CoreGraphics
import Foundation

enum HermitcraftWorld {
    struct PointOfInterest: Hashable, Identifiable {
        var id: Self { self }

        var name: String
        var location: CGPoint
    }
    /// The seed for Hermitcraft Season 10.
    static let seed = 5103687417315433447

    /// A small collection containing points of interest on the Hermitcraft map.
    /// - SeeAlso: https://maps.hermitcraft.dinip.pt/season10/#world_isometric_day_final/0/15/-550/-174/62
    static let pointsOfInterest = [
        PointOfInterest(
            name: "Mumbo's Village",
            location: CGPoint(x: -575, y: -604)
        ),
        PointOfInterest(
            name: "Gem's Village",
            location: CGPoint(x: -815, y: -255)
        ),
        PointOfInterest(
            name: "Metro Mayhem",
            location: CGPoint(x: -421, y: -196)
        ),
        PointOfInterest(
            name: "Beef's Home on the Range",
            location: CGPoint(x: -173, y: 201)
        ),
        PointOfInterest(
            name: "Original Spawn",
            location: CGPoint.zero
        )
    ]
}
