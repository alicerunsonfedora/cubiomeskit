//
//  HermitcraftMap.swift
//  HermitcraftMaps
//
//  Created by Marquis Kurt on 29-10-2025.
//

import SwiftUI

struct HermitcraftMap: View {
    var body: some View {
        ContentUnavailableView(
            "Welcome to Hermitcraft",
            systemImage: "globe")
        .navigationTitle("Hermitcraft")
    }
}
